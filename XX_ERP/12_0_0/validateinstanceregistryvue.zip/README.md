# Public Assets

Place your static assets in this directory. They will be served at the root path.

## Required Images

The following images are referenced in the application:

1. **logo_triniti.png** - Company logo (230x66px recommended)
   - Referenced in: RollbackView.vue
   - Path: `/logo_triniti.png`

2. **refresh.png** - Refresh/select icon for instance selector
   - Referenced in: RollbackView.vue
   - Path: `/refresh.png`

3. **hourglass.png** - Loading indicator (optional, can use CSS spinner instead)
   - Path: `/hourglass.png`

4. **favicon.ico** - Browser favicon
   - Path: `/favicon.ico`

## Usage

Simply copy your image files to this directory and they will be accessible at the root URL.

Example:
- File: `public/logo_triniti.png`
- Access: `http://localhost:5173/logo_triniti.png`
